import streamlit as st
from typing import Dict, List, Tuple, Optional

# ============================================================================
# CONSTANTES - Conjuntos de dados de filmes
# ============================================================================

HP_TITLES = {
    "HP1": "HP1: A Pedra Filosofal",
    "HP2": "HP2: A Câmara Secreta",
    "HP3": "HP3: O Prisioneiro de Azkaban",
    "HP4": "HP4: O Cálice de Fogo",
    "HP5": "HP5: A Ordem da Fênix",
    "HP6": "HP6: O Enigma do Príncipe",
    "HP7": "HP7: As Relíquias da Morte Parte 1",
    "HP8": "HP8: As Relíquias da Morte Parte 2"
}

SW_TITLES = {
    "SW1": "SW1: A Ameaça Fantasma",
    "SW2": "SW2: Ataque dos Clones",
    "SW3": "SW3: A Vingança dos Sith",
    "SW4": "SW4: Uma Nova Esperança",
    "SW5": "SW5: O Império Contra-Ataca",
    "SW6": "SW6: O Retorno de Jedi",
    "SW7": "SW7: O Despertar da Força",
    "SW8": "SW8: Os Últimos Jedi",
    "SW9": "SW9: A Ascensão Skywalker",
    "SWX": "Rogue One: Uma História Star Wars"
}

# Perfis padrão
DEFAULT_RANKINGS = {
    "hp": {
        "Ale": ["HP2", "HP4", "HP1", "HP3", "HP5", "HP7", "HP8", "HP6"],
        "Leo": ["HP6", "HP4", "HP5", "HP3", "HP1", "HP7", "HP8", "HP2"]
    },
    "sw": {
        "Ale": ["SW5", "SW6", "SW7", "SW4", "SW1", "SW8", "SWX", "SW3", "SW9", "SW2"],
        "Leo": ["SW5", "SW6", "SW3", "SWX", "SW4", "SW1", "SW2", "SW7", "SW8", "SW9"]
    }
}

# ============================================================================
# FUNÇÕES AUXILIARES
# ============================================================================

def get_titles(saga: str) -> Dict[str, str]:
    """Obter dicionário de títulos para uma saga."""
    return HP_TITLES if saga == "hp" else SW_TITLES

def get_defaults(saga: str) -> Dict[str, List[str]]:
    """Obter classificações padrão para uma saga."""
    return DEFAULT_RANKINGS[saga]

def to_codes(seq: List[str], saga: str) -> List[str]:
    """Converter títulos para códigos, filtrando desconhecidos."""
    titles = get_titles(saga)
    code_set = set(titles.keys())
    return [item for item in seq if item in code_set]

def ranks_map(seq: List[str]) -> Dict[str, int]:
    """Converter sequência para {código: classificação baseada em 1} mapeamento."""
    return {code: idx + 1 for idx, code in enumerate(seq)}

def levenshtein_seq(a: List[str], b: List[str]) -> int:
    """
    Computar distância de Levenshtein entre duas sequências usando programação dinâmica.
    Inserir/excluir/substituir custam 1.
    """
    m, n = len(a), len(b)
    # Criar tabela DP
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    
    # Inicializar casos base
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j
    
    # Preencher tabela DP
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if a[i-1] == b[j-1]:
                dp[i][j] = dp[i-1][j-1]
            else:
                dp[i][j] = 1 + min(
                    dp[i-1][j],    # exclusão
                    dp[i][j-1],    # inserção
                    dp[i-1][j-1]   # substituição
                )
    
    return dp[m][n]

def wmape_on_ranks(ref_seq: List[str], cmp_seq: List[str]) -> float:
    """
    Computar WMAPE nas classificações sobre a interseção de itens.
    Retorna NaN se não houver itens comuns.
    """
    r1 = ranks_map(ref_seq)
    r2 = ranks_map(cmp_seq)
    
    # Encontrar interseção
    common = set(r1.keys()) & set(r2.keys())
    if not common:
        return float('nan')
    
    abs_err = sum(abs(r1[it] - r2[it]) for it in common)
    denominator = sum(r1[it] for it in common)
    
    if denominator == 0:
        return float('nan')
    
    return abs_err / denominator

def similarity_from_wmape(w: float) -> float:
    """Converter WMAPE para pontuação de similaridade (1 - w), limitada a [0,1]."""
    if w != w:  # Verificação de NaN
        return float('nan')
    return max(0.0, min(1.0, 1.0 - w))

def compare_one(input_codes: List[str], ref_codes: List[str], saga: str) -> Dict:
    """
    Comparar classificação do usuário contra um perfil de referência.
    Retorna dict com pontuação, métricas de Levenshtein e métricas de WMAPE.
    """
    titles = get_titles(saga)
    n_total = len(titles)
    
    # Distância e similaridade de Levenshtein
    lev_dist = levenshtein_seq(input_codes, ref_codes)
    lev_norm = lev_dist / n_total if n_total > 0 else 0.0
    lev_sim = 1.0 - lev_norm
    
    # WMAPE e similaridade
    wmape = wmape_on_ranks(ref_codes, input_codes)
    wmape_sim = similarity_from_wmape(wmape)
    
    # Pontuação final (média das similaridades, tratando NaN)
    if wmape_sim != wmape_sim:  # wmape_sim é NaN
        score = lev_sim
    elif lev_sim != lev_sim:  # lev_sim é NaN (não deve acontecer)
        score = wmape_sim
    else:
        score = (lev_sim + wmape_sim) / 2.0
    
    return {
        "score": score,
        "levenshtein_distance": lev_dist,
        "levenshtein_normalized": lev_norm,
        "levenshtein_similarity": lev_sim,
        "wmape": wmape,
        "wmape_similarity": wmape_sim
    }

# ============================================================================
# INICIALIZAÇÃO DO ESTADO DA SESSÃO
# ============================================================================

def init_session_state():
    """Inicializar variáveis do estado da sessão."""
    if 'page' not in st.session_state:
        st.session_state['page'] = 'home'
    if 'saga' not in st.session_state:
        st.session_state['saga'] = None
    if 'user_ranking' not in st.session_state:
        st.session_state['user_ranking'] = None

# ============================================================================
# VISUALIZAÇÃO 1: INÍCIO
# ============================================================================

def show_home():
    """Exibe a página inicial com seleção de saga."""
    st.title("🎬 Comparador de Rankings")
    st.markdown("### Compare seus rankings de filmes com Ale e Leo!")
    st.markdown("Escolha uma saga para classificar e veja o quanto seu gosto combina.")
    
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### ⚡ Harry Potter")
        st.markdown("Classifique todos os 8 filmes do mundo bruxo")
        if st.button("Escolher Harry Potter", use_container_width=True, type="primary"):
            st.session_state['saga'] = 'hp'
            st.session_state['page'] = 'ranking'
            st.rerun()
    
    with col2:
        st.markdown("### 🌟 Star Wars")
        st.markdown("Classifique 10 filmes de uma galáxia muito, muito distante")
        if st.button("Escolher Star Wars", use_container_width=True, type="primary"):
            st.session_state['saga'] = 'sw'
            st.session_state['page'] = 'ranking'
            st.rerun()

# ============================================================================
# VISUALIZAÇÃO 2: CLASSIFICAÇÃO
# ============================================================================

def show_ranking():
    """Exibe a interface de classificação com tabela interativa."""
    saga = st.session_state['saga']
    titles = get_titles(saga)
    codes = sorted(titles.keys())
    
    saga_name = "Harry Potter" if saga == "hp" else "Star Wars"
    st.title(f"📊 Classifique os Filmes de {saga_name}")
    st.markdown(f"Atribua uma classificação única (1-{len(codes)}) para cada filme. 1 = seu favorito!")
    
    # Opção de pré-preenchimento
    prefill = st.checkbox("Pré-preencher em ordem alfabética (para teste)")
    
    # Inicializar dados de classificação no estado da sessão
    if 'ranking_data' not in st.session_state or st.session_state.get('last_saga') != saga:
        if prefill:
            st.session_state['ranking_data'] = {code: idx + 1 for idx, code in enumerate(codes)}
        else:
            st.session_state['ranking_data'] = {code: None for code in codes}
        st.session_state['last_saga'] = saga
    
    st.markdown("---")
    
    # Criar tabela interativa
    st.markdown("### Suas Classificações")
    
    # Exibir tabela com entradas numéricas
    for code in codes:
        col1, col2, col3 = st.columns([1, 1, 4])
        with col1:
            st.markdown(f"**{code}**")
        with col2:
            rank = st.number_input(
                "Posição",
                min_value=1,
                max_value=len(codes),
                value=st.session_state['ranking_data'][code],
                key=f"rank_{code}",
                label_visibility="collapsed"
            )
            st.session_state['ranking_data'][code] = rank
        with col3:
            st.markdown(titles[code])
    
    st.markdown("---")
    
    # Validação
    ranks = [st.session_state['ranking_data'][code] for code in codes]
    all_filled = all(r is not None for r in ranks)
    unique_ranks = len(ranks) == len(set(ranks)) if all_filled else True
    
    if not all_filled:
        st.warning("⚠️ Por favor, preencha todas as posições antes de enviar.")
    elif not unique_ranks:
        st.error("❌ Cada posição deve ser única! Por favor, corrija as posições duplicadas.")
    
    # Botão de ordenar por posição
    col1, col2, col3 = st.columns([1, 1, 1])
    with col1:
        if st.button("🔄 Ordenar por Posição", use_container_width=True):
            # Ordenar códigos por suas posições para visualização
            sorted_codes = sorted(codes, key=lambda c: st.session_state['ranking_data'][c] or 999)
            st.markdown("#### Visualização (ordenado por posição):")
            for code in sorted_codes:
                rank = st.session_state['ranking_data'][code]
                st.markdown(f"{rank}. **{code}** - {titles[code]}")
    
    with col2:
        if st.button("🏠 Voltar ao Início", use_container_width=True):
            st.session_state['page'] = 'home'
            st.rerun()
    
    with col3:
        if st.button("✅ Enviar Classificações", use_container_width=True, type="primary", disabled=not (all_filled and unique_ranks)):
            # Criar lista final de classificação ordenada por posição
            sorted_codes = sorted(codes, key=lambda c: st.session_state['ranking_data'][c])
            st.session_state['user_ranking'] = sorted_codes
            st.session_state['page'] = 'results'
            st.rerun()

# ============================================================================
# VISUALIZAÇÃO 3: RESULTADOS
# ============================================================================

def show_results():
    """Exibe resultados da comparação com pontuações e vencedor."""
    saga = st.session_state['saga']
    user_ranking = st.session_state['user_ranking']
    defaults = get_defaults(saga)
    
    saga_name = "Harry Potter" if saga == "hp" else "Star Wars"
    
    # Calcular pontuações
    ale_result = compare_one(user_ranking, defaults['Ale'], saga)
    leo_result = compare_one(user_ranking, defaults['Leo'], saga)
    
    # Determinar vencedor
    ale_score = ale_result['score']
    leo_score = leo_result['score']
    
    if ale_score > leo_score:
        winner = "Ale"
    elif leo_score > ale_score:
        winner = "Leo"
    else:
        winner = "Empate"
    
    # Mostrar animação de celebração
    st.balloons()
    
    # Exibir resultados
    st.title(f"🏆 Resultados: {saga_name}")
    
    if winner == "Empate":
        st.markdown("## 🤝 É um Empate!")
        st.markdown("Suas classificações combinam igualmente com Ale e Leo!")
    else:
        st.markdown(f"## 🎉 Vencedor: {winner}!")
        st.markdown(f"Suas classificações de {saga_name} são mais similares ao gosto de {winner}!")
    
    # Animação de progresso
    progress_bar = st.progress(0)
    for i in range(100):
        progress_bar.progress(i + 1)
    progress_bar.empty()
    
    st.markdown("---")
    
    # Painel de métricas
    st.markdown("### 📈 Pontuações de Similaridade")
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### Ale")
        st.metric("Pontuação Geral", f"{ale_score:.3f}")
        st.metric("Similaridade Levenshtein", f"{ale_result['levenshtein_similarity']:.3f}")
        st.caption(f"Distância: {ale_result['levenshtein_distance']}, Normalizada: {ale_result['levenshtein_normalized']:.3f}")
        st.metric("Similaridade WMAPE", f"{ale_result['wmape_similarity']:.3f}")
        st.caption(f"WMAPE: {ale_result['wmape']:.3f}")
    
    with col2:
        st.markdown("#### Leo")
        st.metric("Pontuação Geral", f"{leo_score:.3f}")
        st.metric("Similaridade Levenshtein", f"{leo_result['levenshtein_similarity']:.3f}")
        st.caption(f"Distância: {leo_result['levenshtein_distance']}, Normalizada: {leo_result['levenshtein_normalized']:.3f}")
        st.metric("Similaridade WMAPE", f"{leo_result['wmape_similarity']:.3f}")
        st.caption(f"WMAPE: {leo_result['wmape']:.3f}")
    
    st.markdown("---")
    
    # Gráfico de barras de comparação
    st.markdown("### 📊 Comparação de Pontuações")
    st.bar_chart({"Ale": ale_score, "Leo": leo_score})
    
    st.markdown("---")
    
    # Tabela de números brutos
    st.markdown("### 📋 Métricas Detalhadas")
    import pandas as pd
    
    df = pd.DataFrame({
        "Métrica": ["Pontuação Geral", "Similaridade Levenshtein", "Distância Levenshtein", "Levenshtein Normalizada", "WMAPE", "Similaridade WMAPE"],
        "Ale": [
            f"{ale_score:.3f}",
            f"{ale_result['levenshtein_similarity']:.3f}",
            ale_result['levenshtein_distance'],
            f"{ale_result['levenshtein_normalized']:.3f}",
            f"{ale_result['wmape']:.3f}",
            f"{ale_result['wmape_similarity']:.3f}"
        ],
        "Leo": [
            f"{leo_score:.3f}",
            f"{leo_result['levenshtein_similarity']:.3f}",
            leo_result['levenshtein_distance'],
            f"{leo_result['levenshtein_normalized']:.3f}",
            f"{leo_result['wmape']:.3f}",
            f"{leo_result['wmape_similarity']:.3f}"
        ]
    })
    
    st.dataframe(df, use_container_width=True)
    
    st.markdown("---")
    
    # Botão voltar ao início
    if st.button("🏠 Voltar ao Início", use_container_width=True, type="primary"):
        st.session_state['page'] = 'home'
        st.session_state['ranking_data'] = None
        st.rerun()

# ============================================================================
# APLICATIVO PRINCIPAL
# ============================================================================

def main():
    """Ponto de entrada principal do aplicativo."""
    st.set_page_config(
        page_title="Comparador de Rankings",
        page_icon="🎬",
        layout="centered"
    )
    
    init_session_state()
    
    # Rotear para a visualização apropriada
    page = st.session_state['page']
    
    if page == 'home':
        show_home()
    elif page == 'ranking':
        show_ranking()
    elif page == 'results':
        show_results()

if __name__ == "__main__":
    main()
